/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.6838636363636363, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.45, 500, 1500, "logout"], "isController": false}, {"data": [1.0, 500, 1500, "JDBC Request"], "isController": false}, {"data": [0.39, 500, 1500, "娱乐"], "isController": false}, {"data": [0.395, 500, 1500, "体育"], "isController": false}, {"data": [0.42, 500, 1500, "formhash"], "isController": false}, {"data": [1.0, 500, 1500, "name"], "isController": false}, {"data": [1.0, 500, 1500, "调试取样器"], "isController": false}, {"data": [1.0, 500, 1500, "pwd"], "isController": false}, {"data": [0.4216666666666667, 500, 1500, "login"], "isController": false}, {"data": [0.395, 500, 1500, "财经"], "isController": false}, {"data": [0.415, 500, 1500, "HTTP Request Defaults"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 2200, 0, 0.0, 689.3940909090904, 0, 6074, 556.0, 1597.6000000000004, 1890.8999999999996, 4083.859999999975, 84.26213183193535, 164.42576075299704, 49.68200470862538], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["logout", 300, 0, 0.0, 1135.4933333333329, 63, 2306, 1134.0, 1757.7, 1888.95, 2079.4300000000003, 12.421331566743955, 63.96100251790742, 13.292442137297117], "isController": false}, {"data": ["JDBC Request", 100, 0, 0.0, 111.85000000000004, 14, 444, 78.5, 261.30000000000007, 372.6999999999997, 443.88999999999993, 8.719155985700585, 0.48534364373528643, 0.0], "isController": false}, {"data": ["娱乐", 100, 0, 0.0, 1210.17, 150, 2395, 1208.5, 1809.2, 1916.0, 2391.6799999999985, 4.082632481424023, 3.6992477749652974, 5.42623321017392], "isController": false}, {"data": ["体育", 100, 0, 0.0, 1216.1000000000008, 263, 2506, 1225.5, 1880.9000000000003, 2003.2499999999998, 2502.9099999999985, 4.156103237604421, 3.7722319053655293, 5.529646653297868], "isController": false}, {"data": ["formhash", 100, 0, 0.0, 1150.2400000000002, 405, 2266, 1104.5, 1937.5000000000002, 2052.8999999999996, 2265.3799999999997, 6.631739505272233, 38.281133426454005, 6.2002878589429], "isController": false}, {"data": ["name", 300, 0, 0.0, 2.47, 0, 63, 1.0, 2.0, 21.799999999999955, 33.99000000000001, 12.540757461750689, 0.0, 0.0], "isController": false}, {"data": ["调试取样器", 300, 0, 0.0, 0.15000000000000002, 0, 1, 0.0, 1.0, 1.0, 1.0, 12.554402410445261, 9.68724171932541, 0.0], "isController": false}, {"data": ["pwd", 300, 0, 0.0, 0.6133333333333342, 0, 9, 0.0, 1.0, 2.0, 7.980000000000018, 12.549675800041832, 0.0, 0.0], "isController": false}, {"data": ["login", 300, 0, 0.0, 1483.5799999999995, 321, 6074, 1029.5, 3797.7000000000003, 4377.099999999999, 5595.710000000001, 12.103606874848705, 21.24403645202937, 11.521869389473895], "isController": false}, {"data": ["财经", 100, 0, 0.0, 1228.1799999999998, 396, 2456, 1213.0, 1717.6000000000001, 1818.9999999999998, 2451.7899999999977, 4.138216428719222, 3.7496120422098076, 5.504231972894683], "isController": false}, {"data": ["HTTP Request Defaults", 200, 0, 0.0, 1191.6050000000014, 472, 2472, 1193.5, 1656.7, 1848.8, 2180.5700000000015, 8.62738331464067, 48.97657665430075, 8.54388979057027], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 2200, 0, null, null, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
